<?php
require_once("../Config.php");
require_once("db_con.php");

require_once('common/geo/yandex.php');
require_once('common/geo/YndxReverseCode.php');

require_once(ABSOLUTE_PATH.'controllers/ClientDestination_Controller.php');

$contr = new ClientDestination_Controller($dbLink);

$cnt = 0;
$id = $dbLink->query("select id,value from client_destinations where zone_center is null order by id");
while ($ar=$dbLink->fetch_array($id)){
	
	$pm = $contr->getPublicMethod("update");
	$pm->setParamValue("old_id",$ar['id']);
	$pm->setParamValue("value",$ar['value']);
	$cnt++;
	
	$contr->update($pm);
	//break;
	/*
	$res = array();
	$addr = array('region'=>$ar['value'],
			'raion'=>'',
			'city'=>'',
			'naspunkt'=>'',
			'street'=>'',
			'building'=>'',
			'korpus'=>''
	);
	
	get_inf_on_address($addr,$res);
	if ($res['lon_pos'] &amp;&amp; $res['lat_pos']){
		$pm->setParamValue('zone_center',
			$res['lon_pos'].' '.$res['lat_pos']
			);
	}
	*/
}
echo 'Count='.$cnt;
?>
