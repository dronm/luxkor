<?php
/**
 *
 * THIS FILE IS GENERATED FROM TEMPLATE build/templates/models/Model_php.xsl
 * ALL DIRECT MODIFICATIONS WILL BE LOST WITH THE NEXT BUILD PROCESS!!!
 *
 */

require_once(FRAME_WORK_PATH.'basic_classes/ModelSQL.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLInt.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLText.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLFloat.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLEnum.php');
require_once(FRAME_WORK_PATH.'basic_classes/FieldSQLDateTime.php');
 
class AccPKO_Model extends ModelSQL{
	
	public function __construct($dbLink){
		parent::__construct($dbLink);
		
		
		$this->setDbName('public');
		
		$this->setTableName("acc_pkos");
			
		//*** Field id ***
		$f_opts = array();
		$f_opts['primaryKey'] = TRUE;
		$f_opts['autoInc']=TRUE;
		$f_opts['id']="id";
						
		$f_id=new FieldSQLInt($this->getDbLink(),$this->getDbName(),$this->getTableName(),"id",$f_opts);
		$this->addField($f_id);
		//********************
		
		//*** Field date_time ***
		$f_opts = array();
		$f_opts['id']="date_time";
						
		$f_date_time=new FieldSQLDateTime($this->getDbLink(),$this->getDbName(),$this->getTableName(),"date_time",$f_opts);
		$this->addField($f_date_time);
		//********************
		
		//*** Field acc_pko_type ***
		$f_opts = array();
		$f_opts['id']="acc_pko_type";
						
		$f_acc_pko_type=new FieldSQLEnum($this->getDbLink(),$this->getDbName(),$this->getTableName(),"acc_pko_type",$f_opts);
		$this->addField($f_acc_pko_type);
		//********************
		
		//*** Field total ***
		$f_opts = array();
		$f_opts['length']=15;
		$f_opts['id']="total";
						
		$f_total=new FieldSQLFloat($this->getDbLink(),$this->getDbName(),$this->getTableName(),"total",$f_opts);
		$this->addField($f_total);
		//********************
		
		//*** Field order_list ***
		$f_opts = array();
		$f_opts['id']="order_list";
						
		$f_order_list=new FieldSQLText($this->getDbLink(),$this->getDbName(),$this->getTableName(),"order_list",$f_opts);
		$this->addField($f_order_list);
		//********************
		
		//*** Field order_ids ***
		$f_opts = array();
		$f_opts['id']="order_ids";
						
		$f_order_ids=new FieldSQLText($this->getDbLink(),$this->getDbName(),$this->getTableName(),"order_ids",$f_opts);
		$this->addField($f_order_ids);
		//********************
	
	}

}
?>
