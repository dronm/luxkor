<?php
/**
	DO NOT MODIFY THIS FILE!	
	Its content is generated automaticaly from template placed at build/permissions/permission_php.tmpl.	
 */
function method_allowed($contrId,$methId){
$permissions = array();

					$permissions['User_Controller_insert']=TRUE;
				
					$permissions['User_Controller_update']=TRUE;
				
					$permissions['User_Controller_delete']=TRUE;
				
					$permissions['User_Controller_get_list']=TRUE;
				
					$permissions['User_Controller_get_object']=TRUE;
				
					$permissions['User_Controller_complete']=TRUE;
				
					$permissions['User_Controller_login']=TRUE;
				
					$permissions['User_Controller_logout']=TRUE;
				
					$permissions['User_Controller_login_html']=TRUE;
				
					$permissions['User_Controller_logged']=TRUE;
				
					$permissions['User_Controller_get_account']=TRUE;
				
					$permissions['User_Controller_complete_from_1c']=TRUE;
				
					$permissions['Constant_Controller_set_value']=TRUE;
				
					$permissions['Constant_Controller_get_list']=TRUE;
				
					$permissions['Constant_Controller_get_object']=TRUE;
				
					$permissions['Constant_Controller_get_values']=TRUE;
				
					$permissions['Enum_Controller_get_enum_list']=TRUE;
				
					$permissions['Firm_Controller_insert']=TRUE;
				
					$permissions['Firm_Controller_update']=TRUE;
				
					$permissions['Firm_Controller_delete']=TRUE;
				
					$permissions['Firm_Controller_get_list']=TRUE;
				
					$permissions['Firm_Controller_get_object']=TRUE;
				
					$permissions['Firm_Controller_get_firm_ext_bank_account_list']=TRUE;
				
					$permissions['Warehouse_Controller_insert']=TRUE;
				
					$permissions['Warehouse_Controller_update']=TRUE;
				
					$permissions['Warehouse_Controller_delete']=TRUE;
				
					$permissions['Warehouse_Controller_get_list']=TRUE;
				
					$permissions['Warehouse_Controller_get_object']=TRUE;
				
					$permissions['Warehouse_Controller_get_list_for_order']=TRUE;
				
					$permissions['Product_Controller_insert']=TRUE;
				
					$permissions['Product_Controller_update']=TRUE;
				
					$permissions['Product_Controller_delete']=TRUE;
				
					$permissions['Product_Controller_get_list']=TRUE;
				
					$permissions['Product_Controller_get_object']=TRUE;
				
					$permissions['Product_Controller_get_list_for_order']=TRUE;
				
					$permissions['Product_Controller_upsert']=TRUE;
				
					$permissions['Product_Controller_create_in_1c']=TRUE;
				
					$permissions['Product_Controller_get_filter_list']=TRUE;
				
					$permissions['Product_Controller_complete']=TRUE;
				
					$permissions['Product_Controller_complete_from_1c']=TRUE;
				
					$permissions['ProductCustomSizePrice_Controller_insert']=TRUE;
				
					$permissions['ProductCustomSizePrice_Controller_update']=TRUE;
				
					$permissions['ProductCustomSizePrice_Controller_delete']=TRUE;
				
					$permissions['ProductCustomSizePrice_Controller_get_list']=TRUE;
				
					$permissions['ProductCustomSizePrice_Controller_get_object']=TRUE;
				
					$permissions['ProductWarehouse_Controller_insert']=TRUE;
				
					$permissions['ProductWarehouse_Controller_update']=TRUE;
				
					$permissions['ProductWarehouse_Controller_delete']=TRUE;
				
					$permissions['ProductWarehouse_Controller_get_list']=TRUE;
				
					$permissions['ProductWarehouse_Controller_get_object']=TRUE;
				
					$permissions['MeasureUnit_Controller_insert']=TRUE;
				
					$permissions['MeasureUnit_Controller_update']=TRUE;
				
					$permissions['MeasureUnit_Controller_delete']=TRUE;
				
					$permissions['MeasureUnit_Controller_get_list']=TRUE;
				
					$permissions['MeasureUnit_Controller_get_object']=TRUE;
				
					$permissions['ProductMeasureUnit_Controller_insert']=TRUE;
				
					$permissions['ProductMeasureUnit_Controller_update']=TRUE;
				
					$permissions['ProductMeasureUnit_Controller_delete']=TRUE;
				
					$permissions['ProductMeasureUnit_Controller_get_list']=TRUE;
				
					$permissions['ProductMeasureUnit_Controller_get_object']=TRUE;
				
					$permissions['Client_Controller_insert']=TRUE;
				
					$permissions['Client_Controller_update']=TRUE;
				
					$permissions['Client_Controller_delete']=TRUE;
				
					$permissions['Client_Controller_get_list']=TRUE;
				
					$permissions['Client_Controller_get_object']=TRUE;
				
					$permissions['Client_Controller_complete']=TRUE;
				
					$permissions['Client_Controller_get_unreg_list']=TRUE;
				
					$permissions['Client_Controller_get_unreg_client_list']=TRUE;
				
					$permissions['Client_Controller_get_user_list']=TRUE;
				
					$permissions['Client_Controller_get_contract_list']=TRUE;
				
					$permissions['Client_Controller_complete_from_1c']=TRUE;
				
					$permissions['Client_Controller_attrs_from_1c']=TRUE;
				
					$permissions['Client_Controller_register']=TRUE;
				
					$permissions['Client_Controller_check_on_user_name']=TRUE;
				
					$permissions['Client_Controller_check_on_inn']=TRUE;
				
					$permissions['Client_Controller_get_pop_firm']=TRUE;
				
					$permissions['Client_Controller_get_debts_on_firm']=TRUE;
				
					$permissions['Client_Controller_get_debt_list']=TRUE;
				
					$permissions['Client_Controller_refresh_debts']=TRUE;
				
					$permissions['Client_Controller_get_client_ext_contract_list']=TRUE;
				
					$permissions['ClientContract_Controller_insert']=TRUE;
				
					$permissions['ClientContract_Controller_update']=TRUE;
				
					$permissions['ClientContract_Controller_delete']=TRUE;
				
					$permissions['ClientContract_Controller_get_list']=TRUE;
				
					$permissions['ClientContract_Controller_get_object']=TRUE;
				
					$permissions['ClientUser_Controller_insert']=TRUE;
				
					$permissions['ClientUser_Controller_update']=TRUE;
				
					$permissions['ClientUser_Controller_delete']=TRUE;
				
					$permissions['ClientUser_Controller_get_list']=TRUE;
				
					$permissions['ClientUser_Controller_get_object']=TRUE;
				
					$permissions['ClientUser_Controller_reset_pwd']=TRUE;
				
					$permissions['ClientPriceList_Controller_insert']=TRUE;
				
					$permissions['ClientPriceList_Controller_update']=TRUE;
				
					$permissions['ClientPriceList_Controller_delete']=TRUE;
				
					$permissions['ClientPriceList_Controller_get_list']=TRUE;
				
					$permissions['ClientPriceList_Controller_get_object']=TRUE;
				
					$permissions['ClientPriceList_Controller_tune']=TRUE;
				
					$permissions['ClientPriceList_Controller_print_price']=TRUE;
				
					$permissions['ClientPriceListProduct_Controller_insert']=TRUE;
				
					$permissions['ClientPriceListProduct_Controller_update']=TRUE;
				
					$permissions['ClientPriceListProduct_Controller_delete']=TRUE;
				
					$permissions['ClientPriceListProduct_Controller_get_list']=TRUE;
				
					$permissions['ClientPriceListProduct_Controller_get_obj']=TRUE;
				
					$permissions['ClientPriceListProduct_Controller_set_values']=TRUE;
				
					$permissions['ClientPriceListClient_Controller_insert']=TRUE;
				
					$permissions['ClientPriceListClient_Controller_delete']=TRUE;
				
					$permissions['ClientPriceListClient_Controller_get_list']=TRUE;
				
					$permissions['ProductionCity_Controller_insert']=TRUE;
				
					$permissions['ProductionCity_Controller_update']=TRUE;
				
					$permissions['ProductionCity_Controller_delete']=TRUE;
				
					$permissions['ProductionCity_Controller_get_list']=TRUE;
				
					$permissions['ProductionCity_Controller_get_object']=TRUE;
				
					$permissions['DOCOrder_Controller_insert']=TRUE;
				
					$permissions['DOCOrder_Controller_update']=TRUE;
				
					$permissions['DOCOrder_Controller_divide']=TRUE;
				
					$permissions['DOCOrder_Controller_delete']=TRUE;
				
					$permissions['DOCOrder_Controller_get_new_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_current_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_current_for_representative_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_current_for_client_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_current_for_production_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_closed_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_object']=TRUE;
				
					$permissions['DOCOrder_Controller_get_cust_survey']=TRUE;
				
					$permissions['DOCOrder_Controller_get_divis']=TRUE;
				
					$permissions['DOCOrder_Controller_before_open']=TRUE;
				
					$permissions['DOCOrder_Controller_get_actions']=TRUE;
				
					$permissions['DOCOrder_Controller_get_print']=TRUE;
				
					$permissions['DOCOrder_Controller_download_print']=TRUE;
				
					$permissions['DOCOrder_Controller_get_print_check']=TRUE;
				
					$permissions['DOCOrder_Controller_set_ready']=TRUE;
				
					$permissions['DOCOrder_Controller_get_shipment']=TRUE;
				
					$permissions['DOCOrder_Controller_get_products_descr']=TRUE;
				
					$permissions['DOCOrder_Controller_cancel']=TRUE;
				
					$permissions['DOCOrder_Controller_cancel_last_state']=TRUE;
				
					$permissions['DOCOrder_Controller_get_history']=TRUE;
				
					$permissions['DOCOrder_Controller_pass_to_production']=TRUE;
				
					$permissions['DOCOrder_Controller_get_print_all']=TRUE;
				
					$permissions['DOCOrder_Controller_get_print_cnt']=TRUE;
				
					$permissions['DOCOrder_Controller_set_printed']=TRUE;
				
					$permissions['DOCOrder_Controller_set_shipped']=TRUE;
				
					$permissions['DOCOrder_Controller_get_ship_docs']=TRUE;
				
					$permissions['DOCOrder_Controller_print_ship_docs']=TRUE;
				
					$permissions['DOCOrder_Controller_set_paid']=TRUE;
				
					$permissions['DOCOrder_Controller_set_not_paid']=TRUE;
				
					$permissions['DOCOrder_Controller_paid_to_acc']=TRUE;
				
					$permissions['DOCOrder_Controller_set_paid_by_bank']=TRUE;
				
					$permissions['DOCOrder_Controller_paid_by_bank_to_acc']=TRUE;
				
					$permissions['DOCOrder_Controller_set_closed']=TRUE;
				
					$permissions['DOCOrder_Controller_print_order']=TRUE;
				
					$permissions['DOCOrder_Controller_ext_ship_exists']=TRUE;
				
					$permissions['DOCOrder_Controller_ext_invoice_exists']=TRUE;
				
					$permissions['DOCOrder_Controller_ext_order_exists']=TRUE;
				
					$permissions['DOCOrder_Controller_print_torg12']=TRUE;
				
					$permissions['DOCOrder_Controller_print_invoice']=TRUE;
				
					$permissions['DOCOrder_Controller_print_upd']=TRUE;
				
					$permissions['DOCOrder_Controller_print_ttn']=TRUE;
				
					$permissions['DOCOrder_Controller_print_passport']=TRUE;
				
					$permissions['DOCOrder_Controller_pay_orders_list']=TRUE;
				
					$permissions['DOCOrder_Controller_fill_cust_surv']=TRUE;
				
					$permissions['DOCOrder_Controller_set_cancel_cause']=TRUE;
				
					$permissions['DOCOrder_Controller_calc_totals']=TRUE;
				
					$permissions['DOCOrder_Controller_calc_quant']=TRUE;
				
					$permissions['DOCOrder_Controller_recalc_product_prices']=TRUE;
				
					$permissions['DOCOrder_Controller_calc_deliv_cost']=TRUE;
				
					$permissions['DOCOrder_Controller_get_pop_warehouse']=TRUE;
				
					$permissions['DOCOrder_Controller_get_children']=TRUE;
				
					$permissions['DOCOrder_Controller_get_cancel_cause']=TRUE;
				
					$permissions['DOCOrder_Controller_get_append_list']=TRUE;
				
					$permissions['DOCOrder_Controller_append']=TRUE;
				
					$permissions['DOCOrder_Controller_add_file']=TRUE;
				
					$permissions['DOCOrder_Controller_delete_file']=TRUE;
				
					$permissions['DOCOrder_Controller_get_file']=TRUE;
				
					$permissions['DOCOrder_Controller_get_files_list']=TRUE;
				
					$permissions['DOCOrder_Controller_get_nonegraphic_files_list']=TRUE;
				
					$permissions['DOCOrderDOCTProduct_Controller_insert']=TRUE;
				
					$permissions['DOCOrderDOCTProduct_Controller_update']=TRUE;
				
					$permissions['DOCOrderDOCTProduct_Controller_delete']=TRUE;
				
					$permissions['DOCOrderDOCTProduct_Controller_get_list']=TRUE;
				
					$permissions['DOCOrderDOCTProduct_Controller_get_object']=TRUE;
				
					$permissions['DOCOrderDOCTProduct_Controller_get_object_for_divis']=TRUE;
				
					$permissions['DOCOrderDOCTCustSurvey_Controller_insert']=TRUE;
				
					$permissions['DOCOrderDOCTCustSurvey_Controller_update']=TRUE;
				
					$permissions['DOCOrderDOCTCustSurvey_Controller_delete']=TRUE;
				
					$permissions['DOCOrderDOCTCustSurvey_Controller_get_list']=TRUE;
				
					$permissions['DOCOrderDOCTCustSurvey_Controller_get_object']=TRUE;
				
					$permissions['DeliveryPeriod_Controller_insert']=TRUE;
				
					$permissions['DeliveryPeriod_Controller_update']=TRUE;
				
					$permissions['DeliveryPeriod_Controller_delete']=TRUE;
				
					$permissions['DeliveryPeriod_Controller_get_list']=TRUE;
				
					$permissions['DeliveryPeriod_Controller_get_object']=TRUE;
				
					$permissions['ProductionState_Controller_insert']=TRUE;
				
					$permissions['ProductionState_Controller_update']=TRUE;
				
					$permissions['ProductionState_Controller_delete']=TRUE;
				
					$permissions['ProductionState_Controller_get_list']=TRUE;
				
					$permissions['ProductionState_Controller_get_object']=TRUE;
				
					$permissions['Kladr_Controller_get_region_list']=TRUE;
				
					$permissions['Kladr_Controller_get_raion_list']=TRUE;
				
					$permissions['Kladr_Controller_get_naspunkt_list']=TRUE;
				
					$permissions['Kladr_Controller_get_gorod_list']=TRUE;
				
					$permissions['Kladr_Controller_get_ulitsa_list']=TRUE;
				
					$permissions['Kladr_Controller_get_from_naspunkt']=TRUE;
				
					$permissions['Kladr_Controller_get_prior_region_list']=TRUE;
				
					$permissions['CustomerSurveyQuestion_Controller_insert']=TRUE;
				
					$permissions['CustomerSurveyQuestion_Controller_update']=TRUE;
				
					$permissions['CustomerSurveyQuestion_Controller_delete']=TRUE;
				
					$permissions['CustomerSurveyQuestion_Controller_get_list']=TRUE;
				
					$permissions['CustomerSurveyQuestion_Controller_get_object']=TRUE;
				
					$permissions['CustomerSurvey_Controller_insert']=TRUE;
				
					$permissions['CustomerSurvey_Controller_update']=TRUE;
				
					$permissions['CustomerSurvey_Controller_delete']=TRUE;
				
					$permissions['CustomerSurvey_Controller_get_list']=TRUE;
				
					$permissions['CustomerSurvey_Controller_get_object']=TRUE;
				
					$permissions['Payment_Controller_get_schedule']=TRUE;
				
					$permissions['Payment_Controller_get_def_debt_details']=TRUE;
				
					$permissions['ReportVariant_Controller_insert']=TRUE;
				
					$permissions['ReportVariant_Controller_update']=TRUE;
				
					$permissions['ReportVariant_Controller_delete']=TRUE;
				
					$permissions['ReportVariant_Controller_get_list']=TRUE;
				
					$permissions['ReportVariant_Controller_get_object']=TRUE;
				
					$permissions['Report_Controller_production_load']=TRUE;
				
					$permissions['Report_Controller_naspunkt_cost']=TRUE;
				
					$permissions['Report_Controller_client_balance']=TRUE;
				
					$permissions['Report_Controller_sales']=TRUE;
				
					$permissions['Report_Controller_vehicle_stops']=TRUE;
				
					$permissions['Report_Controller_client_debts']=TRUE;
				
					$permissions['Delivery_Controller_unassigned_orders_list']=TRUE;
				
					$permissions['Delivery_Controller_assigned_orders_list']=TRUE;
				
					$permissions['Delivery_Controller_assigned_orders_for_client']=TRUE;
				
					$permissions['Delivery_Controller_add_extra_vehicle']=TRUE;
				
					$permissions['Delivery_Controller_extra_veh_select_list']=TRUE;
				
					$permissions['Delivery_Controller_delete_extra_vehicle']=TRUE;
				
					$permissions['Delivery_Controller_current_position_all']=TRUE;
				
					$permissions['Delivery_Controller_current_position_client']=TRUE;
				
					$permissions['Delivery_Controller_get_order_descr']=TRUE;
				
					$permissions['Delivery_Controller_assign_order_to_vehicle']=TRUE;
				
					$permissions['Delivery_Controller_remove_order']=TRUE;
				
					$permissions['Driver_Controller_insert']=TRUE;
				
					$permissions['Driver_Controller_update']=TRUE;
				
					$permissions['Driver_Controller_delete']=TRUE;
				
					$permissions['Driver_Controller_get_list']=TRUE;
				
					$permissions['Driver_Controller_get_object']=TRUE;
				
					$permissions['Driver_Controller_complete']=TRUE;
				
					$permissions['Driver_Controller_get_veh_attrs']=TRUE;
				
					$permissions['Carrier_Controller_insert']=TRUE;
				
					$permissions['Carrier_Controller_update']=TRUE;
				
					$permissions['Carrier_Controller_delete']=TRUE;
				
					$permissions['Carrier_Controller_get_list']=TRUE;
				
					$permissions['Carrier_Controller_get_object']=TRUE;
				
					$permissions['Vehicle_Controller_insert']=TRUE;
				
					$permissions['Vehicle_Controller_update']=TRUE;
				
					$permissions['Vehicle_Controller_delete']=TRUE;
				
					$permissions['Vehicle_Controller_get_list']=TRUE;
				
					$permissions['Vehicle_Controller_get_select_list']=TRUE;
				
					$permissions['Vehicle_Controller_get_object']=TRUE;
				
					$permissions['Vehicle_Controller_complete']=TRUE;
				
					$permissions['ClientDestination_Controller_insert']=TRUE;
				
					$permissions['ClientDestination_Controller_update']=TRUE;
				
					$permissions['ClientDestination_Controller_delete']=TRUE;
				
					$permissions['ClientDestination_Controller_get_list']=TRUE;
				
					$permissions['ClientDestination_Controller_get_object']=TRUE;
				
					$permissions['ClientDestination_Controller_get_address_gps']=TRUE;
				
					$permissions['ClientDestination_Controller_complete_address']=TRUE;
				
					$permissions['SMSTemplate_Controller_insert']=TRUE;
				
					$permissions['SMSTemplate_Controller_update']=TRUE;
				
					$permissions['SMSTemplate_Controller_delete']=TRUE;
				
					$permissions['SMSTemplate_Controller_get_list']=TRUE;
				
					$permissions['SMSTemplate_Controller_get_object']=TRUE;
				
					$permissions['EmailTemplate_Controller_insert']=TRUE;
				
					$permissions['EmailTemplate_Controller_update']=TRUE;
				
					$permissions['EmailTemplate_Controller_delete']=TRUE;
				
					$permissions['EmailTemplate_Controller_get_list']=TRUE;
				
					$permissions['EmailTemplate_Controller_get_object']=TRUE;
				
					$permissions['DelivCostOpt_Controller_insert']=TRUE;
				
					$permissions['DelivCostOpt_Controller_update']=TRUE;
				
					$permissions['DelivCostOpt_Controller_delete']=TRUE;
				
					$permissions['DelivCostOpt_Controller_get_list']=TRUE;
				
					$permissions['DelivCostOpt_Controller_get_object']=TRUE;
				
					$permissions['DelivCost_Controller_insert']=TRUE;
				
					$permissions['DelivCost_Controller_update']=TRUE;
				
					$permissions['DelivCost_Controller_delete']=TRUE;
				
					$permissions['DelivCost_Controller_get_list']=TRUE;
				
					$permissions['DelivCost_Controller_get_object']=TRUE;
				
					$permissions['Holiday_Controller_insert']=TRUE;
				
					$permissions['Holiday_Controller_update']=TRUE;
				
					$permissions['Holiday_Controller_delete']=TRUE;
				
					$permissions['Holiday_Controller_get_list']=TRUE;
				
					$permissions['Holiday_Controller_get_object']=TRUE;
				
					$permissions['ClientDebtPeriod_Controller_insert']=TRUE;
				
					$permissions['ClientDebtPeriod_Controller_update']=TRUE;
				
					$permissions['ClientDebtPeriod_Controller_delete']=TRUE;
				
					$permissions['ClientDebtPeriod_Controller_get_list']=TRUE;
				
					$permissions['ClientDebtPeriod_Controller_get_object']=TRUE;
				
					$permissions['DeliveryHour_Controller_insert']=TRUE;
				
					$permissions['DeliveryHour_Controller_update']=TRUE;
				
					$permissions['DeliveryHour_Controller_delete']=TRUE;
				
					$permissions['DeliveryHour_Controller_get_list']=TRUE;
				
					$permissions['DeliveryHour_Controller_get_object']=TRUE;
				
					$permissions['ClientActivity_Controller_insert']=TRUE;
				
					$permissions['ClientActivity_Controller_update']=TRUE;
				
					$permissions['ClientActivity_Controller_delete']=TRUE;
				
					$permissions['ClientActivity_Controller_get_list']=TRUE;
				
					$permissions['ClientActivity_Controller_get_object']=TRUE;
				
					$permissions['SertType_Controller_insert']=TRUE;
				
					$permissions['SertType_Controller_update']=TRUE;
				
					$permissions['SertType_Controller_delete']=TRUE;
				
					$permissions['SertType_Controller_get_list']=TRUE;
				
					$permissions['SertType_Controller_get_object']=TRUE;
				
					$permissions['SertType_Controller_set_xslt_pattern']=TRUE;
				
					$permissions['SertType_Controller_get_xslt_pattern']=TRUE;
				
					$permissions['SertType_Controller_check_pattern']=TRUE;
				
					$permissions['SertTypeAttr_Controller_insert']=TRUE;
				
					$permissions['SertTypeAttr_Controller_update']=TRUE;
				
					$permissions['SertTypeAttr_Controller_delete']=TRUE;
				
					$permissions['SertTypeAttr_Controller_get_list']=TRUE;
				
					$permissions['SertTypeAttr_Controller_get_object']=TRUE;
				
					$permissions['TrackerServer_Controller_insert']=TRUE;
				
					$permissions['TrackerServer_Controller_update']=TRUE;
				
					$permissions['TrackerServer_Controller_delete']=TRUE;
				
					$permissions['TrackerServer_Controller_get_list']=TRUE;
				
					$permissions['TrackerServer_Controller_get_object']=TRUE;
				
					$permissions['Tracker_Controller_insert']=TRUE;
				
					$permissions['Tracker_Controller_update']=TRUE;
				
					$permissions['Tracker_Controller_delete']=TRUE;
				
					$permissions['Tracker_Controller_get_list']=TRUE;
				
					$permissions['Tracker_Controller_get_object']=TRUE;
				
					$permissions['UserWarehouse_Controller_insert']=TRUE;
				
					$permissions['UserWarehouse_Controller_update']=TRUE;
				
					$permissions['UserWarehouse_Controller_delete']=TRUE;
				
					$permissions['UserWarehouse_Controller_get_list']=TRUE;
				
					$permissions['UserWarehouse_Controller_get_object']=TRUE;
				
					$permissions['SMSForSending_Controller_get_list']=TRUE;
				
					$permissions['MailForSending_Controller_get_list']=TRUE;
				
					$permissions['ProductGroup_Controller_insert']=TRUE;
				
					$permissions['ProductGroup_Controller_update']=TRUE;
				
					$permissions['ProductGroup_Controller_delete']=TRUE;
				
					$permissions['ProductGroup_Controller_get_list']=TRUE;
				
					$permissions['ProductGroup_Controller_get_object']=TRUE;
				
					$permissions['Naspunkt_Controller_insert']=TRUE;
				
					$permissions['Naspunkt_Controller_update']=TRUE;
				
					$permissions['Naspunkt_Controller_delete']=TRUE;
				
					$permissions['Naspunkt_Controller_get_list']=TRUE;
				
					$permissions['Naspunkt_Controller_get_object']=TRUE;
				
					$permissions['AccPKO_Controller_get_list']=TRUE;
				
					$permissions['AccPKO_Controller_get_object']=TRUE;
				
					$permissions['TemplateParam_Controller_get_list']=TRUE;
				
					$permissions['TemplateParam_Controller_set_value']=TRUE;
				
					$permissions['TTNAttrPair_Controller_insert']=TRUE;
				
					$permissions['TTNAttrPair_Controller_update']=TRUE;
				
					$permissions['TTNAttrPair_Controller_delete']=TRUE;
				
					$permissions['TTNAttrPair_Controller_get_list']=TRUE;
				
					$permissions['TTNAttrPair_Controller_get_object']=TRUE;
				
					$permissions['CarrierOrder_Controller_insert']=TRUE;
				
					$permissions['CarrierOrder_Controller_update']=TRUE;
				
					$permissions['CarrierOrder_Controller_delete']=TRUE;
				
					$permissions['CarrierOrder_Controller_get_list']=TRUE;
				
					$permissions['CarrierOrder_Controller_get_object']=TRUE;
				
					$permissions['ClientSearch_Controller_search']=TRUE;
				
					$permissions['Bank_Controller_get_list']=TRUE;
				
					$permissions['Bank_Controller_get_object']=TRUE;
				
					$permissions['Bank_Controller_complete']=TRUE;
				
					$permissions['ClientFirmBankAccount_Controller_insert']=TRUE;
				
					$permissions['ClientFirmBankAccount_Controller_update']=TRUE;
				
					$permissions['ClientFirmBankAccount_Controller_delete']=TRUE;
				
					$permissions['ClientFirmBankAccount_Controller_get_list']=TRUE;
				
					$permissions['ClientFirmBankAccount_Controller_get_object']=TRUE;
				
					$permissions['Product1cName_Controller_insert']=TRUE;
				
					$permissions['Product1cName_Controller_update']=TRUE;
				
					$permissions['Product1cName_Controller_delete']=TRUE;
				
					$permissions['Product1cName_Controller_get_list']=TRUE;
				
					$permissions['Product1cName_Controller_get_object']=TRUE;
				
					$permissions['SaleStoreAddress_Controller_insert']=TRUE;
				
					$permissions['SaleStoreAddress_Controller_update']=TRUE;
				
					$permissions['SaleStoreAddress_Controller_delete']=TRUE;
				
					$permissions['SaleStoreAddress_Controller_get_list']=TRUE;
				
					$permissions['SaleStoreAddress_Controller_get_object']=TRUE;
				
					$permissions['ProdBatch_Controller_get_list']=TRUE;
				
					$permissions['ProdBatch_Controller_complete_from_1c']=TRUE;
				
					$permissions['DOCOrderDOCTProdBatch_Controller_insert']=TRUE;
				
					$permissions['DOCOrderDOCTProdBatch_Controller_update']=TRUE;
				
					$permissions['DOCOrderDOCTProdBatch_Controller_delete']=TRUE;
				
					$permissions['DOCOrderDOCTProdBatch_Controller_get_list']=TRUE;
				
					$permissions['DOCOrderDOCTProdBatch_Controller_get_object']=TRUE;
				
			$permissions['DOCOrder_Controller_set_not_paid']=FALSE;
		
return array_key_exists($contrId.'_'.$methId,$permissions);
}
?>